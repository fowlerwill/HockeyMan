jQuery(document).ready(function($) {
	$('#contactToggle').click(function(){
		$('#contactForm').slideToggle();
	})

	$('#menu-main li, #menu-mainmenu li').hover(function(){
		$(this).children('ul').filter(':not(:animated)').slideDown();
	},function(){
		$(this).children('ul').slideUp();
	})
});