<?php

/* = Required Files
-----------------------------------------------------------------------------*/
//require_once(dirname(dirname(dirname(dirname(__FILE__)))).'/wp-load.php');
require_once 'HockeyMan.php';
require_once 'HockeyManGame.php';
require_once 'HockeyManPlayer.php';
require_once 'HockeyManEmail.php';
require_once 'HockeyManAjax.php';

/* = Dev Development
-----------------------------------------------------------------------------*/

define("PLAYERS_TABLE", "wp35_hockeymanplayers");
define("GAMES_TABLE", "wp35_hockeymangames");
define("ATTENDANCE_TABLE", "wp35_hockeymanattendance");

define("PRODUCT_NAME", "Incite Team Manager");


